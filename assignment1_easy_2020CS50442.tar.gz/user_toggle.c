//A Simple C program
#include "types.h"
#include "stat.h"
#include "user.h"
	
//passing command line arguments
	
int main(void) 
{
    toggle();
    exit();
}

// This code is from GFG for testing 
