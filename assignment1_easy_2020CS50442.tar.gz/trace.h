#define TOT 70
#define TRACE_ON 1
#define TRACE_OFF 0





