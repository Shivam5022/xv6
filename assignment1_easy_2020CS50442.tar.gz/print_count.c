//A Simple C program
#include "types.h"
#include "stat.h"
#include "user.h"
	
//passing command line arguments
	
int main(void) 
{
    printf(1, "%d\n", print_count());
    exit();
}

// This code is from GFG for testing 
