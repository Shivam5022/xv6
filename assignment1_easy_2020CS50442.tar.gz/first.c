//A Simple C program
#include "types.h"
#include "stat.h"
#include "user.h"
	
//passing command line arguments
	
int main(void) 
{
    printf(1, "Note: Unix V6 was released in year %d\n", getyear());
    exit();
}

// This code is from GFG for testing 

